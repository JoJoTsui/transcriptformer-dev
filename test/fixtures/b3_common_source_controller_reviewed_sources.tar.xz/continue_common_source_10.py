#!/usr/bin/env python
"""Ignored bounded 10-draw continuation; execute only after independent review.

This is a new attempt, not a replacement for the seven-stage representative
study. It reuses that study's completed source freeze, v3 plan and two builds.
No model forward or 2,000-draw job is launched by this driver.
"""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from math import isfinite
import os
from pathlib import Path
import resource
import shutil
import signal
import stat
import subprocess
import sys
import time
from types import ModuleType

for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_key] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = ""

OWN = Path(__file__).resolve()
ROOT = OWN.parents[4]
INSTRUCTIONS = OWN.with_name("COMMON_SOURCE_10_PROBE.md")
REVIEWED_STUDY = OWN.with_name("study_common_source_batches.py")
APP = ROOT / "scripts/bootstrap_b3_paged_native_common_source.py"
SUPERVISOR = ROOT / "scripts/supervise_b3_pilot.py"
STAGES = (("00-admit", "admit"), ("01-execute-10", "execute"),
          ("02-replay-10", "replay"), ("03-qualify", "qualify"))
SCHEMA = "b3_common_source_10_probe_stage_v1"
BINDING_SCHEMA = "b3_common_source_10_probe_binding_v1"
FINAL_SCHEMA = "b3_common_source_10_probe_driver_v1"
GATE_SCHEMA = "b3_common_source_10_probe_cost_gate_v1"
ADMISSION_GATE_SCHEMA = "b3_common_source_10_admission_cost_gate_v1"
MIB, GIB = 1024**2, 1024**3
FAILED_50_DRIVER = OWN.with_name("continue_common_source_50.py")
FAILED_50_INSTRUCTIONS = OWN.with_name("COMMON_SOURCE_50_PROBE.md")
FAILED_50_ATTEMPT = ROOT / "runs/b3_feasibility/20261004/common_source_50_attempt01"
FAILED_50_SOURCE_SHA = {
    "driver": "779d36fa820d1773cebc0c104220ecc21ab4fde5a23b7eab9429756636355780",
    "instructions": "fb78175d7d7f7695284c92775ead175f3fcc9ce418bac89370ca3c0c6d38d870",
}
FAILED_50_METADATA_SHA = {
    "root_failure": ("failure.json", "ee0918152aafa27c126ea987e550c17859228732b9fc0d00377d0164b34ef5d7"),
    "stage_failure": ("stages/01-execute-50/failure.json", "b92717b14ab2e49e6db869083ef9e93abb5b94ff19793e797e7aa6634d0a6ab1"),
    "invalid_stage_summary": ("stages/01-execute-50/invalid-summary.json", "5cac41c2bc0727bb2c40646bd84aa152ff11938c15c2919a974014314875b595"),
    "public_summary": ("stages/01-execute-50/public/summary.json", "d1635188f90807027b42181bb8bbad1784c3b1bd24ce602ec7f534938615122b"),
    "supervisor_state": ("supervisors/01-execute-50/state.json", "c335be6a1ad18eade6eb001ca08cd6f9911ec2ef3aa582e4f149dfd8d2f83ebc"),
    "controller_receipt": ("controllers/01-execute-50-receipt.json", "071af6a49fd70346f0941679b740f77c7cdbaa5066cf7f6b7d7000e134df238f"),
    "gnu_child_cost": ("supervisors/01-execute-50/gnu-time.txt", "7d12b24f25b0fe3789c725e1c3e547bfe1eb3c115ee3af9d99884cb668ad32f0"),
}


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def checked_sha(value):
    need(isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value),
         "Require lowercase reviewed SHA256")
    return value


def load_helpers(expected, output_parent, *, max_seconds=900):
    # Verify the exact compile buffer before executing reviewed helper code.
    need(type(max_seconds) in (int, float) and 0 < max_seconds <= 900,
         "Require a positive helper admission deadline at most 900 seconds")
    expected = checked_sha(expected)
    began = time.monotonic()
    parent = Path(output_parent).resolve()
    while not parent.exists():
        parent = parent.parent

    def guard():
        if time.monotonic() - began >= max_seconds:
            raise TimeoutError("Reviewed helper source admission exceeds its deadline")
        if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024 > 4 * GIB:
            raise MemoryError("Reviewed helper admission exceeds the 4 GiB process RSS cap")
        available = None
        with Path("/proc/meminfo").open() as stream:
            for line in stream:
                if line.startswith("MemAvailable:"):
                    available = int(line.split()[1]) * 1024
                    break
        need(available is not None and available >= 4 * GIB,
             "Reviewed helper admission requires 4 GiB available host RAM")
        need(shutil.disk_usage(parent).free >= 20 * GIB,
             "Reviewed helper admission requires 20 GiB free disk")

    guard()
    path = REVIEWED_STUDY.resolve(strict=True)
    limit = 4 * MIB
    initial = path.stat()
    need(stat.S_ISREG(initial.st_mode) and 0 < initial.st_size <= limit,
         "Reviewed helper must be a regular source file no larger than 4 MiB")
    guard()
    descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        opened = os.fstat(stream.fileno())
        need(stat.S_ISREG(opened.st_mode) and opened.st_size == initial.st_size
             and (opened.st_dev, opened.st_ino) == (initial.st_dev, initial.st_ino),
             "Reviewed helper changed before bounded source admission")
        pieces, total = [], 0
        while True:
            guard()
            piece = stream.read(min(MIB, limit - total + 1))
            if not piece:
                break
            total += len(piece)
            need(total <= limit, "Reviewed helper exceeds its 4 MiB source buffer limit")
            pieces.append(piece)
        need(total == opened.st_size and os.fstat(stream.fileno()).st_size == total,
             "Reviewed helper size changed during source admission")
    guard()
    data = b"".join(pieces)
    need(sha256(data).hexdigest() == expected, "Reviewed seven-stage driver bytes changed")
    guard()
    module = ModuleType("_reviewed_common_source_study")
    module.__file__ = str(path)
    need(module.__name__ not in sys.modules, "Reviewed helper runtime name is already registered")
    sys.modules[module.__name__] = module
    try:
        exec(compile(data, str(path), "exec"), module.__dict__)
        guard()
    except BaseException:
        if sys.modules.get(module.__name__) is module:
            sys.modules.pop(module.__name__)
        raise
    return module


def publish_prelaunch_failure(output, error):
    # The reviewed helper itself may have failed byte admission. This small
    # fallback records the zero-launch refusal without executing that helper.
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    value = {"schema": "b3_common_source_10_parent_admission_failure_v1",
             "status": "failed_before_any_child_launch", "child_launch_count": 0,
             "error_type": type(error).__name__, "error": str(error)}
    data = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode() + b"\n"
    with (output / "prelaunch-failure.json").open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def require_ref(helper, ref, check, *, small=False):
    helper.checked_ref(ref)
    actual, data = helper.actual(ref["path"], check, expected=ref,
                                 limit=32 * MIB if small else None, retain=small)
    need(actual == ref, "Bound byte reference changed")
    return helper.strict_json(data) if small else None


def set_reference(refs, ref):
    old = refs.setdefault(ref["path"], ref)
    need(old == ref, "Conflicting byte reference for same path")


def bind_failed_50_diagnostic(helper, stage, failed_root):
    root = Path(failed_root).resolve(strict=True)
    need(root == FAILED_50_ATTEMPT.resolve(strict=True)
         and root.is_dir() and not os.path.lexists(root / "summary.json")
         and not os.path.lexists(root / "stages/01-execute-50/summary.json")
         and not os.path.lexists(root / "stages/02-replay-50")
         and not os.path.lexists(root / "stages/03-qualify"),
         "Require failed 50 attempt with no completed 50 marker/replay/qualify")
    source_refs = {}
    for name, path in (("driver", FAILED_50_DRIVER),
                       ("instructions", FAILED_50_INSTRUCTIONS)):
        ref, _ = helper.actual(path, stage.check, limit=4 * MIB)
        need(ref["sha256"] == FAILED_50_SOURCE_SHA[name],
             "Reviewed failed-50 source changed")
        stage.bind(ref)
        source_refs[name] = ref
    refs, values = {}, {}
    for name, (relative, expected_sha) in FAILED_50_METADATA_SHA.items():
        ref, data = helper.actual(root / relative, stage.check, limit=32 * MIB, retain=True)
        need(ref["sha256"] == expected_sha, "Failed-50 diagnostic metadata changed: " + name)
        stage.bind(ref)
        refs[name] = ref
        values[name] = data.decode() if name == "gnu_child_cost" else helper.strict_json(data)
    root_failure, stage_failure = values["root_failure"], values["stage_failure"]
    invalid, public = values["invalid_stage_summary"], values["public_summary"]
    supervisor, controller = values["supervisor_state"], values["controller_receipt"]
    need(root_failure.get("status") == "failed"
         and root_failure.get("error_type") == "ValueError"
         and root_failure.get("error") == "Supervised stage failed; stop continuation"
         and stage_failure.get("status") == "failed"
         and stage_failure.get("error_type") == "TimeoutError"
         and stage_failure.get("error") == "Study stage wall cap exceeded",
         "Failed 50 root/stage failure scope differs")
    need(invalid.get("schema") == "b3_common_source_50_probe_stage_v1"
         and invalid.get("action") == "execute"
         and invalid.get("status") == "complete"
         and invalid.get("elapsed_before_final_seal_seconds") == 798.8693383089994
         and invalid["details"].get("complete_public_return_monotonic_seconds") == 698.473401826006
         and invalid["details"].get("draw_range") == [0, 50]
         and invalid.get("outputs", {}).get("public_summary") == refs["public_summary"],
         "Invalid 50 stage draft differs; do not promote it to completion")
    need(public.get("schema") == "b3_paged_native_common_bootstrap_shard_v3"
         and public.get("phase") == "production"
         and public.get("start") == 0 and public.get("stop_completed") == 50
         and public.get("stop_requested") == 50 and len(public.get("draws", [])) == 50
         and public.get("model_forwards_performed") is False,
         "Failed-stage public-only 0:50 diagnostic differs")
    need(supervisor.get("status") == "stopped" and supervisor.get("return_code") == 1
         and controller.get("controller_return_code") == 1
         and controller.get("complete_supervised_invocation_monotonic_seconds") ==
         901.5519847889955,
         "Failed-50 supervisor/controller scope differs")
    need("Elapsed (wall clock) time (h:mm:ss or m:ss): 13:52.09" in values["gnu_child_cost"]
         and "Maximum resident set size (kbytes): 763148" in values["gnu_child_cost"]
         and "Exit status: 1" in values["gnu_child_cost"],
         "Failed-50 GNU child cost differs")
    return {
        "scope": "Diagnostic failed 50 attempt only; public return and invalid stage draft are not completed 50-stage receipts",
        "source": source_refs, "metadata": refs,
        "public_50_return_seconds": 698.473401826006,
        "invalid_stage_before_final_seal_seconds": 798.8693383089994,
        "complete_supervised_invocation_seconds": 901.5519847889955,
        "gnu_child_wall_text": "13:52.09", "gnu_child_peak_kbytes": 763148,
        "stage_failed_during_final_seal": True,
        "replay_or_qualification_launched": False,
    }


def derive_10_admission_gate(source_gate, source_gate_ref, failed_50):
    need(source_gate.get("bounded_100_draw_probe_permitted") is False
         and source_gate.get("fit_proven_for_100_draws") is False
         and source_gate.get("full_2000_draw_stage_permitted") is False,
         "Require completed negative 100-draw gate before separate 10-draw admission")
    measurements = source_gate.get("measurement_receipts", {})
    old_forecasts = source_gate.get("forecasts", {})
    need(set(old_forecasts) == {"04-execute", "05-replay"},
         "Require both measured one-draw query forecasts")
    forecasts = {}
    for name in ("04-execute", "05-replay"):
        one = measurements[name]["complete_public_return_seconds"]
        per_draw = old_forecasts[name]["recorded_query_kernels_and_serialization_per_draw_seconds"]
        need(type(one) in (int, float) and type(per_draw) in (int, float)
             and isfinite(one) and isfinite(per_draw) and 0 <= one <= 900
             and 0 <= per_draw <= 900
             and old_forecasts[name]["measured_one_draw_complete_seconds"] == one,
             "Old gate's measured one-draw components differ")
        projection = one + 9 * per_draw + 300.0
        headroom = max(60.0, 0.25 * projection)
        with_headroom = projection + headroom
        need(isfinite(with_headroom) and with_headroom <= 900,
             "One-draw costs do not admit a bounded 10-draw invocation")
        forecasts[name] = {
            "measured_one_draw_complete_seconds": one,
            "recorded_query_kernels_and_serialization_per_draw_seconds": per_draw,
            "extra_draw_count": 9,
            "fixed_engineering_reserve_seconds": 300.0,
            "projected_10_draw_invocation_seconds": projection,
            "reserved_headroom_seconds": headroom,
            "projection_with_headroom_seconds": with_headroom,
            "bounded_10_draw_invocation_admitted": True,
            "unmeasured_extra_draw_costs": old_forecasts[name]["unmeasured_extra_draw_costs"],
        }
    return {
        "schema": ADMISSION_GATE_SCHEMA,
        "status": "derived_from_completed_negative_100_gate_before_any_child_launch",
        "source_100_negative_gate": source_gate_ref,
        "failed_50_diagnostic": failed_50,
        "forecasts": forecasts,
        "bounded_10_draw_probe_permitted": True,
        "original_bounded_100_draw_probe_permitted": False,
        "full_2000_draw_stage_permitted": False,
        "full_2000_draws_completed": False,
        "whole_method_fit_established": False,
        "projection_scope": "One completed representative draw plus 9 recorded query-kernel/serialization increments and an explicit proposed 300-second engineering reserve for outer source/control/final-seal work, followed by max(60 seconds, 25 percent) headroom over that entire projection. The reserve is not an upper-bound guarantee from the failed 50 trace; this only admits a new measured 0:10 production and replay.",
        "synthetic_fixture_only": True,
        "scientific_readiness": "unavailable", "interval": None,
    }


def bind_study(helper, stage, study_root, failed_50_root):
    root = Path(study_root).resolve(strict=True)
    final_ref, final_bytes = helper.actual(root / "summary.json", stage.check, limit=32 * MIB, retain=True)
    final = helper.strict_json(final_bytes)
    need(final.get("schema") == helper.DRIVER_SCHEMA
         and final.get("status") == "completed_one_draw_representative_study_and_cost_gate"
         and final.get("synthetic_fixture_only") is True
         and final.get("whole_method_fit_established") is False
         and final.get("full_2000_draws_completed") is False,
         "Require completed bounded seven-stage study")
    stage.bind(final_ref)
    need(len(final["jobs"]) == len(helper.STAGES), "Seven completed supervised stages required")
    summaries = {}
    for (name, action), job in zip(helper.STAGES, final["jobs"], strict=True):
        need(job.get("name") == name and job.get("action") == action
             and job.get("controller_return_code") == 0, "Seven-stage controller record differs")
        state = require_ref(helper, job["supervisor_state"], stage.check, small=True)
        need(state.get("status") == "completed" and state.get("return_code") == 0,
             "Historical supervised stage did not complete")
        stage.bind(job["supervisor_state"])
        stage.bind(job["gnu_complete_child_cost"])
        marker = require_ref(helper, job["summary"], stage.check, small=True)
        need(marker.get("schema") == helper.STAGE_SCHEMA and marker.get("status") == "complete"
             and marker.get("action") == action, "Historical stage marker differs")
        stage.bind(job["summary"])
        for ref in [*marker["inputs"], *marker["generated_files"]]:
            stage.bind(ref)
        summaries[name] = marker
    binding_ref = summaries["00-freeze"]["outputs"]["binding"]
    freeze = require_ref(helper, binding_ref, stage.check, small=True)
    need(freeze.get("schema") == helper.FREEZE_SCHEMA and freeze.get("synthetic_fixture_only") is True,
         "Historical source freeze differs")
    stage.bind(binding_ref)
    for marker in summaries.values():
        if marker["action"] != "freeze":
            need(marker["binding"] == binding_ref, "Historical stage uses another source freeze")
    gate_ref = final["cost_gate"]
    gate = require_ref(helper, gate_ref, stage.check, small=True)
    stage.bind(gate_ref)
    need(gate_ref == summaries["06-qualify"]["outputs"]["cost_gate"]
         and gate.get("schema") == helper.GATE_SCHEMA,
         "Completed seven-stage cost gate differs")
    failed_50 = bind_failed_50_diagnostic(helper, stage, failed_50_root)
    admission_10_projection = derive_10_admission_gate(gate, gate_ref, failed_50)
    need(freeze["driver_source"]["sha256"] == stage.args.expected_study_sha256,
         "Reviewed old driver differs from source freeze")
    need(freeze["application_consumer_file_sha256"][str(APP)] ==
         stage.args.expected_app_sha256, "Frozen public application differs")
    need(freeze["authenticated_helper_source"]["sha256"] ==
         stage.args.expected_auth_helper_sha256, "Frozen authenticated helper differs")
    for ref in freeze["bound_files"]:
        stage.bind(ref)
    plan_ref = summaries["03-prepare"]["outputs"]["plan"]
    require_ref(helper, plan_ref, stage.check, small=True)
    stage.bind(plan_ref)
    for p, digest in freeze["application_consumer_file_sha256"].items():
        ref, _ = helper.actual(p, stage.check, limit=4 * MIB)
        need(ref["sha256"] == digest, "Frozen application closure bytes differ")
        stage.bind(ref)
    need(len(freeze["original_native_consumer_file_sha256"]) == 67
         and len(freeze["legacy_application_consumer_file_sha256"]) == 74
         and len(freeze["batch_consumer_file_sha256"]) == 69
         and len(freeze["application_consumer_file_sha256"]) == 82,
         "Historical/new consumer closure counts differ")
    return {"source_study_final": final_ref, "source_freeze": binding_ref,
            "source_gate": gate_ref, "source_100_negative_gate": gate_ref,
            "failed_50_diagnostic": failed_50,
            "admission_10_projection": admission_10_projection,
            "source_plan": plan_ref,
            "source_builds": {name: summaries[name]["outputs"]["public_summary"]
                              for name in ("01-build-human", "02-build-mouse")},
            "source_keys": freeze["source_keys"],
            "application_consumer_file_sha256": freeze["application_consumer_file_sha256"]}


class Stage:
    def __init__(self, helper, args, entry_started):
        self.helper, self.args = helper, args
        self.output = Path(args.output).resolve()
        need(not os.path.lexists(self.output), "Never reuse a stage output")
        self.output.parent.mkdir(parents=True, exist_ok=True)
        self.budget = helper.Budget(self.output.parent, args.max_seconds)
        self.budget.began = entry_started
        self.budget.check()
        self.refs, self.outputs, self.details = {}, {}, {}
        self.output.mkdir()
        for path, digest in ((OWN, args.expected_driver_sha256),
                             (INSTRUCTIONS, args.expected_instructions_sha256),
                             (REVIEWED_STUDY, args.expected_study_sha256),
                             (APP, args.expected_app_sha256)):
            ref, _ = helper.actual(path, self.check, limit=4 * MIB)
            need(ref["sha256"] == checked_sha(digest), "Reviewed source bytes differ")
            self.bind(ref)

    def check(self):
        self.budget.check()

    def bind(self, ref):
        require_ref(self.helper, ref, self.check)
        set_reference(self.refs, ref)
        return ref

    def read(self, ref):
        value = require_ref(self.helper, ref, self.check, small=True)
        set_reference(self.refs, ref)
        return value

    def write(self, name, value):
        return self.helper.write_json(self.output / name, value, self.check)

    def previous(self, name):
        root = Path(self.args.binding).parent.parent
        path = root / name / "summary.json"
        ref, data = self.helper.actual(path, self.check, limit=32 * MIB, retain=True)
        marker = self.helper.strict_json(data)
        action = dict(STAGES)[name]
        need(marker.get("schema") == SCHEMA and marker.get("status") == "complete"
             and marker.get("action") == action, "Previous probe stage incomplete")
        if name != "00-admit":
            need(marker.get("binding") == self.binding_ref, "Previous probe stage uses another binding")
        self.bind(ref)
        for item in [*marker["inputs"], *marker["generated_files"]]:
            self.bind(item)
        return marker

    def initialize(self):
        ref, raw = self.helper.actual(self.args.binding, self.check, limit=32 * MIB, retain=True)
        self.binding = self.helper.strict_json(raw)
        need(self.binding.get("schema") == BINDING_SCHEMA
             and self.binding.get("source_study_final") is not None
             and self.binding.get("draw_range") == [0, 10]
             and self.binding.get("source_100_negative_gate") == self.binding.get("source_gate"),
             "Probe binding incomplete")
        self.bind(ref)
        self.binding_ref = ref
        admitted = self.previous("00-admit")
        need(admitted["outputs"]["binding"] == ref, "Probe binding differs from admission marker")
        for item in self.binding["bound_files"]:
            self.bind(item)
        admission = self.read(self.binding["admission_10_gate"])
        need(admission.get("schema") == ADMISSION_GATE_SCHEMA
             and admission.get("source_100_negative_gate") == self.binding["source_gate"]
             and admission.get("bounded_10_draw_probe_permitted") is True
             and admission.get("original_bounded_100_draw_probe_permitted") is False
             and self.helper.canonical(admission) ==
             self.helper.canonical(self.binding["admission_10_projection"]),
             "New 10-draw admission gate differs from immutable binding")
        need(self.binding["driver_source"]["sha256"] == self.args.expected_driver_sha256,
             "Probe driver differs from immutable binding")

    def public(self, action, request):
        consumers = self.binding["application_consumer_file_sha256"]
        need(len(consumers) == 82 and consumers[str(APP)] == self.args.expected_app_sha256,
             "Frozen public application closure differs")
        code = None
        for path, digest in consumers.items():
            ref, data = self.helper.actual(path, self.check, limit=4 * MIB,
                                           retain=path == str(APP))
            need(ref["sha256"] == digest, "Consumer changed before public execution")
            self.bind(ref)
            if path == str(APP):
                code = data
        need(code is not None, "Frozen application source absent")
        module = ModuleType("_common_source_10_" + action)
        module.__file__ = str(APP)
        sys.modules[module.__name__] = module
        exec(compile(code, str(APP), "exec"), module.__dict__)
        need({str(p.resolve()) for p in module.SOFTWARE} == set(consumers),
             "Actual application closure differs from frozen declaration")
        request_ref = self.write("request.json", request)
        self.bind(request_ref)
        began = time.monotonic()
        result = getattr(module, action)(Path(request_ref["path"]), self.output / "public",
                                         max_seconds=self.budget.remaining())
        complete = time.monotonic() - began
        self.check()
        summary_ref, raw = self.helper.actual(self.output / "public/summary.json", self.check,
                                              limit=32 * MIB, retain=True)
        actual = self.helper.strict_json(raw)
        need(self.helper.canonical(result) == self.helper.canonical(actual),
             "Public result differs from complete public summary")
        for flag in ("model_forwards_performed", "checkpoint_tensors_loaded",
                     "native_arithmetic_replay_verified", "native_likelihood_effects_attested"):
            need(result.get(flag) is False, "10-draw result promoted unavailable evidence")
        need(result.get("scientific_readiness") == "unavailable" and result.get("interval") is None,
             "10-draw result promoted scientific readiness")
        self.bind(summary_ref)
        self.outputs.update(request=request_ref, public_summary=summary_ref)
        self.details.update(public_result=result, complete_public_return_monotonic_seconds=complete,
                            complete_public_return_scope="Immediately before API call through return, including public final seals and cleanup")
        return result

    def seal(self):
        for ref in self.refs.values():
            require_ref(self.helper, ref, self.check)
        generated = []
        for path in sorted(self.output.rglob("*")):
            self.check()
            if path.is_file():
                need(len(generated) < 10000, "Too many generated stage files")
                generated.append(self.helper.actual(path, self.check)[0])
        marker = {
            "schema": SCHEMA, "status": "complete", "action": self.args.action,
            "binding": getattr(self, "binding_ref", None),
            "driver_source": self.refs[str(OWN)],
            "inputs": list(self.refs.values()), "generated_files": generated,
            "outputs": self.outputs, "details": self.details,
            "elapsed_before_final_seal_seconds": time.monotonic() - self.budget.began,
            "peak_process_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
            "synthetic_fixture_only": True, "model_forwards_performed": False,
            "checkpoint_tensors_loaded": False, "native_arithmetic_replay_verified": False,
            "native_likelihood_effects_attested": False, "scientific_readiness": "unavailable",
            "interval": None, "full_2000_draws_completed": False,
            "whole_method_fit_established": False,
        }
        try:
            ref = self.write("summary.json", marker)
            for item in [*self.refs.values(), *generated, ref]:
                require_ref(self.helper, item, self.check)
        except BaseException:
            self.helper.invalidate(self.output)
            raise
        return marker


def admit(stage):
    study = bind_study(stage.helper, stage, stage.args.study, stage.args.failed_50)
    parent_gate_ref, parent_gate_bytes = stage.helper.actual(
        stage.args.parent_10_gate, stage.check, limit=32 * MIB, retain=True)
    parent_gate = stage.helper.strict_json(parent_gate_bytes)
    need(stage.helper.canonical(parent_gate) ==
         stage.helper.canonical(study["admission_10_projection"]),
         "Parent's newly derived 10-draw admission differs from seven-stage costs")
    stage.bind(parent_gate_ref)
    study["admission_10_gate"] = parent_gate_ref
    binding = {
        "schema": BINDING_SCHEMA, "driver_source": stage.refs[str(OWN)],
        "instructions": stage.refs[str(INSTRUCTIONS)],
        **study, "bound_files": list(stage.refs.values()),
        "draw_range": [0, 10], "synthetic_fixture_only": True,
        "cooperative_stage_seconds": 900, "supervised_stage_seconds": 950,
        "rss_cap_bytes": 4 * GIB, "numeric_cap_bytes": 200 * MIB,
    }
    stage.outputs["binding"] = stage.write("binding.json", binding)


def query(stage, *, replay):
    action = "replay" if replay else "execute"
    plan_ref = stage.binding["source_plan"]
    plan = stage.read(plan_ref)
    need(plan.get("schema") == "b3_paged_native_common_bootstrap_plan_v3"
         and plan.get("status") == "prepared_complete_fixed_family_catalog",
         "Reuse only completed v3 source plan")
    request = {
        "schema": f"b3_paged_native_common_bootstrap_{action}_request_v3",
        "consumer_file_sha256": stage.binding["application_consumer_file_sha256"],
        "plan": plan_ref, "start": 0, "stop": 10,
    }
    if replay:
        production = stage.previous("01-execute-10")
        catalog_ref = stage.write("production-catalog.json", {
            "schema": "b3_paged_native_common_bootstrap_artifacts_v3",
            "artifacts": [{"file": production["outputs"]["public_summary"]}],
        })
        request["production_catalog"] = catalog_ref
    result = stage.public(action, request)
    need(result.get("schema") == "b3_paged_native_common_bootstrap_shard_v3"
         and result.get("phase") == ("replay" if replay else "production")
         and all(type(result.get(k)) is int and result[k] == v for k, v in
                 (("seed", 20260930), ("start", 0), ("stop_requested", 10), ("stop_completed", 10)))
         and len(result.get("draws", [])) == 10
         and result.get("declared_blocks_native_reconstruction_verified") is True
         and result.get("caller_numeric_bytes_at_public_reconstruction") == 0,
         "Full requested 0:10 public query did not complete")
    control = result["unit_multiplicity_control"]
    need(type(control.get("original_fixed_gene_scores_verified")) is int
         and control["original_fixed_gene_scores_verified"] == 1000
         and control.get("physical_blocks_queried") == 126
         and type(result.get("physical_values_compared")) is int
         and result["physical_values_compared"] == 7_565_140,
         "All original fixed-gene unit controls required")
    if replay:
        need(result.get("prefix_query_replay_verified") is True
             and result["draws"] == production["details"]["public_result"]["draws"]
             and result["physical_values_compared"] == 7_565_140,
             "Fresh 10-draw replay differs from production")
    stage.details.update(draw_range=[0, 10], original_fixed_gene_control=control,
                         measured_actual_10_draws=True, full_2000_draws_completed=False)


def qualify(stage):
    execution = stage.previous("01-execute-10")
    replay = stage.previous("02-replay-10")
    costs = {}
    for name, marker in (("production", execution), ("replay", replay)):
        result = marker["details"]["public_result"]
        complete = marker["details"]["complete_public_return_monotonic_seconds"]
        need(type(complete) in (int, float) and 0 <= complete <= 900,
             "Actual complete public return cost differs")
        timings = result["timings_seconds"]
        costs[name] = {"completed_10_draw_public_return_seconds": complete,
                       "recorded_component_timings_seconds": timings,
                       "receipt": marker["outputs"]["public_summary"]}
    # Two actual 0:10 calls out of a projected 400. The other 398 calls,
    # aggregation, scaled seals and finalizer remain unmeasured.
    projected = 200 * sum(row["completed_10_draw_public_return_seconds"] for row in costs.values())
    gate = {
        "schema": GATE_SCHEMA, "status": "actual_10_draw_production_and_replay_complete",
        "costs": costs, "projected_400_shard_calls_seconds": projected,
        "production_invocation_count_for_2000": 200,
        "replay_invocation_count_for_2000": 200,
        "other_invocations_unmeasured": 398,
        "projection_scope": "One actual 0:10 production and one actual independent 0:10 replay; 199 other production plus 199 other replay invocations, aggregation, scaled seals, arithmetic and finalization remain unmeasured.",
        "source_100_negative_gate": stage.binding["source_100_negative_gate"],
        "admission_10_gate": stage.binding["admission_10_gate"],
        "full_2000_draw_stage_permitted": False, "full_2000_draws_completed": False,
        "whole_method_fit_established": False, "project_likelihood_effects_attested": False,
        "scientific_readiness": "unavailable", "interval": None,
    }
    stage.outputs["cost_gate"] = stage.write("cost-gate.json", gate)
    stage.details.update(actual_10_draw_cost_gate=gate, no_2000_draw_work_launched=True)


class Driver:
    def __init__(self, helper, args, entry_started):
        self.helper, self.args = helper, args
        self.output = Path(args.output).resolve()
        need(not os.path.lexists(self.output), "Never reuse a continuation attempt")
        self.output.parent.mkdir(parents=True, exist_ok=True)
        helper.host_check(self.output.parent)
        self.output.mkdir()
        for part in ("stages", "controllers", "supervisors"):
            (self.output / part).mkdir()
        self.began, self.jobs, self.bound_refs = entry_started, [], {}
        self.check()
        # Parent admission precedes every child launch. A changed supervisor
        # must never execute even as the first admission-stage controller.
        for path, digest in ((OWN, args.expected_driver_sha256),
                             (INSTRUCTIONS, args.expected_instructions_sha256),
                             (REVIEWED_STUDY, args.expected_study_sha256),
                             (APP, args.expected_app_sha256)):
            ref, _ = helper.actual(path, self.check, limit=4 * MIB)
            need(ref["sha256"] == checked_sha(digest), "Reviewed parent source bytes differ")
            self.bind(ref)
        self.source_binding = bind_study(helper, self, args.study, args.failed_50)
        self.admission_10_ref = helper.write_json(
            self.output / "admission-10-gate.json",
            self.source_binding["admission_10_projection"], self.check)
        self.bind(self.admission_10_ref)
        self.source_binding["admission_10_gate"] = self.admission_10_ref
        freeze = require_ref(helper, self.source_binding["source_freeze"], self.check, small=True)
        supervisor_digest = freeze["original_source_file_sha256"].get(str(SUPERVISOR))
        need(supervisor_digest is not None, "Original source freeze omitted supervisor")
        supervisor_ref, _ = helper.actual(SUPERVISOR, self.check, limit=4 * MIB)
        need(supervisor_ref["sha256"] == supervisor_digest,
             "Supervisor bytes differ from accepted original source freeze")
        self.bind(supervisor_ref)
        auth_ref = freeze["authenticated_helper_source"]
        need(auth_ref["sha256"] == checked_sha(args.expected_auth_helper_sha256),
             "Authentication helper differs from reviewed expected SHA")
        self.bind(auth_ref)
        self.prelaunch_ref = helper.write_json(self.output / "prelaunch.json", {
            "schema": "b3_common_source_10_parent_admission_v1",
            "status": "new_10_projection_from_negative_100_gate_and_sources_authenticated_before_child_launch",
            "source_study_final": self.source_binding["source_study_final"],
            "source_freeze": self.source_binding["source_freeze"],
            "source_100_negative_gate": self.source_binding["source_100_negative_gate"],
            "failed_50_diagnostic": self.source_binding["failed_50_diagnostic"],
            "admission_10_gate": self.admission_10_ref,
            "admission_10_projection": self.source_binding["admission_10_projection"],
            "source_plan": self.source_binding["source_plan"],
            "supervisor_source": supervisor_ref,
            "reviewed_driver_source": self.bound_refs[str(OWN)],
            "reviewed_instructions": self.bound_refs[str(INSTRUCTIONS)],
            "reviewed_application_source": self.bound_refs[str(APP)],
            "reviewed_authentication_helper": auth_ref,
            "original_native_consumer_files": 67, "original_application_consumer_files": 74,
            "new_native_consumer_files": 69, "new_application_consumer_files": 82,
            "child_launch_count_at_admission": 0,
        }, self.check)
        self.bind(self.prelaunch_ref)

    def check(self):
        need(time.monotonic() - self.began < 4500, "Four-stage continuation exceeds total wall cap")
        self.helper.host_check(self.output.parent)

    def bind(self, ref):
        require_ref(self.helper, ref, self.check)
        set_reference(self.bound_refs, ref)
        return ref

    def verify(self):
        for ref in self.bound_refs.values():
            require_ref(self.helper, ref, self.check)

    def run_stage(self, name, action):
        self.check()
        self.verify()
        output = self.output / "stages" / name
        supervised = self.output / "supervisors" / name
        need(not os.path.lexists(output) and not os.path.lexists(supervised), "Stage already exists")
        fields = ["--expected-driver-sha256", self.args.expected_driver_sha256,
                  "--expected-instructions-sha256", self.args.expected_instructions_sha256,
                  "--expected-study-sha256", self.args.expected_study_sha256,
                  "--expected-app-sha256", self.args.expected_app_sha256,
                  "--expected-auth-helper-sha256", self.args.expected_auth_helper_sha256]
        fields += ["--study", str(Path(self.args.study).resolve()),
                   "--failed-50", str(Path(self.args.failed_50).resolve()),
                   "--parent-10-gate", str(Path(self.admission_10_ref["path"]).resolve())] if action == "admit" else [
            "--binding", str(self.output / "stages/00-admit/binding.json")]
        python = ROOT / ".venv/bin/python"
        child = ["/usr/bin/time", "-v", "-o", str(supervised / "gnu-time.txt"),
                 str(python), str(OWN), "stage", "--action", action, "--output", str(output),
                 "--max-seconds", "900", *fields]
        argv = [str(python), str(SUPERVISOR), "--run-dir", str(supervised),
                "--max-wall-seconds", "950", "--max-rss-gib", "4", "--min-host-ram-gib", "4",
                "--min-disk-gib", "20", "--", *child]
        # Repeat every source/freeze/admission check at the final parent
        # boundary before Popen, including the supervisor and new 10 gate.
        self.verify()
        began = time.monotonic()
        with (self.output / "controllers" / (name + ".log")).open("xb") as log:
            controller = subprocess.Popen(argv, cwd=ROOT, env=dict(os.environ), stdout=log,
                                          stderr=subprocess.STDOUT, start_new_session=True)
            try:
                identity = self.helper.proc_identity(controller.pid)
                need(identity["group"] == controller.pid, "Supervisor does not own a new process group")
                while controller.poll() is None:
                    self.check()
                    need(time.monotonic() - began <= 955, "Supervisor exceeded wall allowance")
                    time.sleep(0.5)
            except BaseException:
                if "identity" in locals():
                    self.helper.stop_owned(controller, identity)
                raise
        state_ref, state_bytes = self.helper.actual(supervised / "state.json", self.check,
                                                    limit=32 * MIB, retain=True)
        state = self.helper.strict_json(state_bytes)
        gnu_ref, _ = self.helper.actual(supervised / "gnu-time.txt", self.check)
        job = {"name": name, "action": action, "argv": argv,
               "controller_return_code": controller.returncode,
               "supervisor_state": state_ref, "gnu_complete_child_cost": gnu_ref,
               "complete_supervised_invocation_monotonic_seconds": time.monotonic() - began,
               "rss_scope": "Per-process guard and GNU child peak; no aggregate memory proof"}
        self.jobs.append(job)
        self.helper.write_json(self.output / "controllers" / (name + "-receipt.json"), job, self.check)
        need(controller.returncode == 0 and state.get("status") == "completed"
             and state.get("return_code") == 0, "Supervised stage failed; stop continuation")
        ref, data = self.helper.actual(output / "summary.json", self.check, limit=32 * MIB, retain=True)
        marker = self.helper.strict_json(data)
        need(marker.get("schema") == SCHEMA and marker.get("status") == "complete"
             and marker.get("action") == action, "Stage completion marker differs")
        for item in [*marker["inputs"], *marker["generated_files"], ref]:
            require_ref(self.helper, item, self.check)
            set_reference(self.bound_refs, item)
        for item in (state_ref, gnu_ref):
            set_reference(self.bound_refs, item)
        job["summary"] = ref
        return marker

    def finish(self, last):
        gate_ref = last["outputs"]["cost_gate"]
        require_ref(self.helper, gate_ref, self.check, small=True)
        private_files = []
        for path in sorted(self.output.rglob("*")):
            self.check()
            if path.is_file():
                need(len(private_files) < 10000, "Too many private continuation files")
                private_files.append(self.helper.actual(path, self.check)[0])
        marker = {
            "schema": FINAL_SCHEMA, "status": "completed_actual_10_draw_probe_and_independent_replay",
            "driver_source": self.helper.actual(OWN, self.check)[0],
            "source_study": self.helper.actual(Path(self.args.study) / "summary.json", self.check)[0],
            "source_100_negative_gate": self.source_binding["source_100_negative_gate"],
            "failed_50_diagnostic": self.source_binding["failed_50_diagnostic"],
            "admission_10_gate": self.admission_10_ref,
            "cost_gate": gate_ref, "jobs": self.jobs,
            "private_generated_files": private_files,
            "elapsed_before_final_seal_seconds": time.monotonic() - self.began,
            "synthetic_fixture_only": True, "model_forwards_performed": False,
            "checkpoint_tensors_loaded": False, "native_arithmetic_replay_verified": False,
            "native_likelihood_effects_attested": False, "scientific_readiness": "unavailable",
            "interval": None, "full_2000_draws_completed": False,
            "whole_method_fit_established": False,
        }
        try:
            summary = self.helper.write_json(self.output / "summary.json", marker, self.check)
            for ref in [*self.bound_refs.values(), *private_files]:
                require_ref(self.helper, ref, self.check)
            require_ref(self.helper, gate_ref, self.check)
            require_ref(self.helper, summary, self.check)
        except BaseException:
            self.helper.invalidate(self.output)
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    for mode in ("run", "stage"):
        p = sub.add_parser(mode)
        p.add_argument("--output", type=Path, required=True)
        p.add_argument("--expected-driver-sha256", required=True)
        p.add_argument("--expected-instructions-sha256", required=True)
        p.add_argument("--expected-study-sha256", required=True)
        p.add_argument("--expected-app-sha256", required=True)
        p.add_argument("--expected-auth-helper-sha256", required=True)
        p.add_argument("--study", type=Path)
        p.add_argument("--failed-50", type=Path)
        p.add_argument("--binding", type=Path)
        p.add_argument("--parent-10-gate", type=Path)
    stage_parser = sub.choices["stage"]
    stage_parser.add_argument("--action", choices=[action for _, action in STAGES], required=True)
    stage_parser.add_argument("--max-seconds", type=float, default=900)
    args = parser.parse_args()
    need(not os.path.lexists(args.output), "Output already exists")
    if args.mode == "run" or args.action == "admit":
        need(args.study is not None and args.failed_50 is not None,
             "Completed seven-stage and failed-50 diagnostic paths required")
        if args.mode == "stage":
            need(args.parent_10_gate is not None, "Parent's new 10 gate reference required")
    else:
        need(args.binding is not None, "Completed continuation binding required")
    output = Path(args.output).resolve()
    entry_started = time.monotonic()
    try:
        helper = load_helpers(
            args.expected_study_sha256, output.parent,
            max_seconds=args.max_seconds if args.mode == "stage" else 900,
        )
        need(time.monotonic() - entry_started < (args.max_seconds if args.mode == "stage" else 4500),
             "Helper admission exhausted this stage/parent wall budget")
    except BaseException as error:
        if args.mode == "run":
            publish_prelaunch_failure(output, error)
        raise
    driver = None
    try:
        if args.mode == "run":
            driver = Driver(helper, args, entry_started)
            last = None
            for name, action in STAGES:
                last = driver.run_stage(name, action)
            driver.finish(last)
        else:
            stage = Stage(helper, args, entry_started)
            if args.action == "admit":
                admit(stage)
            else:
                stage.initialize()
                if args.action == "execute":
                    query(stage, replay=False)
                elif args.action == "replay":
                    query(stage, replay=True)
                else:
                    qualify(stage)
            stage.seal()
    except BaseException as error:
        if output.is_dir():
            if args.mode == "run" and driver is None:
                helper.write_json(output / "prelaunch-failure.json", {
                    "schema": "b3_common_source_10_parent_admission_failure_v1",
                    "status": "failed_before_any_child_launch", "child_launch_count": 0,
                    "error_type": type(error).__name__, "error": str(error),
                }, lambda: None)
            helper.fail(output, error, lambda: None)
        raise


if __name__ == "__main__":
    main()
