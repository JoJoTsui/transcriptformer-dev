#!/usr/bin/env python
"""Capture only a completed, bounded 10-draw engineering measurement.

This ignored collector never calls the application, reads H5/numeric payloads,
or promotes the 10-draw probe to scientific or full-cohort acceptance. Bounded
metadata admission and byte pinning come from an exact reviewed collector.
"""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
from types import ModuleType

OWN_CALLER = Path(__file__).absolute()
OWN = OWN_CALLER.resolve()
ROOT = OWN.parents[4]
BASE = ROOT / "runs/b3_feasibility/20261004"
DRAFT = BASE / "common_source_draft"
HELPER = DRAFT / "capture_common_source_evidence.py"
HELPER_SHA = "b049e3ac98e588c4dcbe3ddaddf39728232ec194fb4dbae941bad3723ab61866"
HEAD = "71c12543277895678bef85f4d9524a183234d0bd"
DRIVER_SHA = "e799a6ee3c06d610d99d0e9127296e577f6c926e58521a58aa77f1794897b077"
INSTRUCTIONS_SHA = "653bd452bd0581414cfa1107fdbea6a1b3b60bdc3995fc6b2d8c3065a5bd90c8"
REVIEW_SHA = "f3a2a5c7981fc3b0a1c00d40692c5a48b9641f475a866d42bd6e9e1660b96ed9"
FAILED_50_SHA = {
    "source": {
        "driver": "779d36fa820d1773cebc0c104220ecc21ab4fde5a23b7eab9429756636355780",
        "instructions": "fb78175d7d7f7695284c92775ead175f3fcc9ce418bac89370ca3c0c6d38d870",
    },
    "metadata": {
        "root_failure": "ee0918152aafa27c126ea987e550c17859228732b9fc0d00377d0164b34ef5d7",
        "stage_failure": "b92717b14ab2e49e6db869083ef9e93abb5b94ff19793e797e7aa6634d0a6ab1",
        "invalid_stage_summary": "5cac41c2bc0727bb2c40646bd84aa152ff11938c15c2919a974014314875b595",
        "public_summary": "d1635188f90807027b42181bb8bbad1784c3b1bd24ce602ec7f534938615122b",
        "supervisor_state": "c335be6a1ad18eade6eb001ca08cd6f9911ec2ef3aa582e4f149dfd8d2f83ebc",
        "controller_receipt": "071af6a49fd70346f0941679b740f77c7cdbaa5066cf7f6b7d7000e134df238f",
        "gnu_child_cost": "7d12b24f25b0fe3789c725e1c3e547bfe1eb3c115ee3af9d99884cb668ad32f0",
    },
}
PUBLIC_SHA = {
    "scripts/prepare_b3_paged_native_common_source.py": "ac14388571b878a69c20ac3f452eaf7f529ac9c77f829f64fbced59ddeb15086",
    "scripts/bootstrap_b3_paged_native_common_source.py": "9d32e5d187388b68649fe7d6ae54b2765367bb5ce335ad0f3e452e7788593bbd",
    "scripts/b3_authenticated_helpers.py": "a931e9d2ee1a35a13d2e7659fa71ff6e1565e289d5ab6c6f15170701525487f3",
}
STAGES = (("00-admit", "admit"), ("01-execute-10", "execute"),
          ("02-replay-10", "replay"), ("03-qualify", "qualify"))
SCHEMA = "b3_common_source_10_engineering_evidence_v1"


def need(ok: bool, reason: str) -> None:
    if not ok:
        raise ValueError(reason)


def finite(value: object, label: str, high: float | None = None) -> float:
    need(type(value) in (int, float) and math.isfinite(value) and value >= 0,
         f"Invalid {label}")
    if high is not None:
        need(value <= high, f"{label} exceeds cap")
    return float(value)


def checked_sha(value: str) -> str:
    need(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None,
         "Expected lowercase SHA-256")
    return value


def admitted_source(path: Path, expected: str) -> tuple[dict, bytes]:
    """Read at most 4 MiB from a regular nofollow source and retain the buffer."""
    checked_sha(expected)
    path = path.resolve(strict=True)
    first = path.stat()
    need(stat.S_ISREG(first.st_mode) and 0 < first.st_size <= 4 * 1024**2,
         f"Invalid retained source size/type: {path}")
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        opened = os.fstat(stream.fileno())
        need(stat.S_ISREG(opened.st_mode)
             and (opened.st_dev, opened.st_ino, opened.st_size)
             == (first.st_dev, first.st_ino, first.st_size),
             f"Retained source changed before read: {path}")
        pieces, total = [], 0
        while True:
            piece = stream.read(min(1024**2, 4 * 1024**2 - total + 1))
            if not piece:
                break
            total += len(piece)
            need(total <= 4 * 1024**2, f"Retained source grew: {path}")
            pieces.append(piece)
        final_fd = os.fstat(stream.fileno())
        need((final_fd.st_dev, final_fd.st_ino, final_fd.st_size)
             == (opened.st_dev, opened.st_ino, opened.st_size)
             and total == opened.st_size, f"Retained source changed during read: {path}")
    need((path.stat().st_dev, path.stat().st_ino, path.stat().st_size)
         == (opened.st_dev, opened.st_ino, opened.st_size),
         f"Retained source changed after read: {path}")
    data = b"".join(pieces)
    ref = {"path": str(path), "sha256": sha256(data).hexdigest(), "bytes": len(data)}
    need(ref["sha256"] == expected, f"Retained source SHA differs: {path}")
    return ref, data


def load_reviewed_helper() -> tuple[ModuleType, dict]:
    ref, buffer = admitted_source(HELPER, HELPER_SHA)
    name = "_reviewed_common_source_capture_10_private"
    need(name not in sys.modules, "Private helper module collision")
    module = ModuleType(name)
    module.__file__ = str(HELPER)
    sys.modules[name] = module
    try:
        exec(compile(buffer, str(HELPER), "exec"), module.__dict__)
    except BaseException:
        if sys.modules.get(name) is module:
            del sys.modules[name]
        raise
    return module, ref


def exact_json(helper: ModuleType, ref: dict) -> dict:
    helper.exact_ref(ref, metadata=True)
    return helper.load(Path(ref["path"]))


def metadata_path(helper: ModuleType, path: Path, expected: str | None = None) -> dict:
    ref = helper.small_ref(path)
    if expected is not None:
        need(ref["sha256"] == expected, f"Metadata SHA differs: {path}")
    return ref


def flags(value: dict, label: str) -> None:
    need(value.get("synthetic_fixture_only") is True
         and all(value.get(k) is False for k in (
             "model_forwards_performed", "checkpoint_tensors_loaded",
             "native_arithmetic_replay_verified", "native_likelihood_effects_attested",
             "full_2000_draws_completed", "whole_method_fit_established"))
         and value.get("scientific_readiness") == "unavailable"
         and value.get("interval", object()) is None,
         f"{label} promotes unavailable scientific evidence")


def validate_admission(gate: dict, negative: dict, failed: dict) -> None:
    need(gate.get("schema") == "b3_common_source_10_admission_cost_gate_v1"
         and gate.get("source_100_negative_gate") == negative
         and gate.get("failed_50_diagnostic") == failed
         and gate.get("bounded_10_draw_probe_permitted") is True
         and gate.get("original_bounded_100_draw_probe_permitted") is False
         and gate.get("full_2000_draw_stage_permitted") is False,
         "Separate bounded-10 admission differs")
    forecasts = gate.get("forecasts")
    need(isinstance(forecasts, dict) and set(forecasts) == {"04-execute", "05-replay"},
         "Both 10-draw admission forecasts required")
    for name, item in forecasts.items():
        one = finite(item.get("measured_one_draw_complete_seconds"), f"{name} one-draw")
        per = finite(item.get("recorded_query_kernels_and_serialization_per_draw_seconds"),
                     f"{name} query component")
        need(item.get("extra_draw_count") == 9
             and item.get("fixed_engineering_reserve_seconds") == 300.0,
             f"{name} reserve/draw count differs")
        projection = one + 9 * per + 300.0
        headroom = max(60.0, .25 * projection)
        need(math.isclose(item.get("projected_10_draw_invocation_seconds"), projection,
                          rel_tol=0, abs_tol=1e-8)
             and math.isclose(item.get("reserved_headroom_seconds"), headroom,
                              rel_tol=0, abs_tol=1e-8)
             and math.isclose(item.get("projection_with_headroom_seconds"),
                              projection + headroom, rel_tol=0, abs_tol=1e-8)
             and projection + headroom <= 900
             and item.get("bounded_10_draw_invocation_admitted") is True,
             f"{name} admission arithmetic differs")


def validate_public(value: dict, phase: str) -> dict:
    need(value.get("schema") == "b3_paged_native_common_bootstrap_shard_v3"
         and value.get("phase") == phase
         and all(type(value.get(k)) is int and value[k] == v for k, v in (
             ("seed", 20260930), ("start", 0), ("stop_requested", 10),
             ("stop_completed", 10), ("physical_values_compared", 7_565_140)))
         and isinstance(value.get("draws"), list) and len(value["draws"]) == 10
         and value.get("declared_blocks_native_reconstruction_verified") is True
         and value.get("caller_numeric_bytes_at_public_reconstruction") == 0,
         f"Incomplete actual {phase} 0:10 public result")
    need(all(isinstance(row, dict) and type(row.get("index")) is int
             and row["index"] == index for index, row in enumerate(value["draws"])),
         f"{phase} draw indices are not exactly 0:10")
    control = value.get("unit_multiplicity_control")
    need(isinstance(control, dict)
         and type(control.get("original_fixed_gene_scores_verified")) is int
         and control["original_fixed_gene_scores_verified"] == 1000
         and type(control.get("physical_blocks_queried")) is int
         and control["physical_blocks_queried"] == 126,
         f"Original physical/unit control differs in {phase}")
    need(all(value.get(k) is False for k in (
             "model_forwards_performed", "checkpoint_tensors_loaded",
             "native_arithmetic_replay_verified", "native_likelihood_effects_attested"))
         and value.get("scientific_readiness") == "unavailable"
         and value.get("interval", object()) is None,
         f"{phase} public result promotes scientific evidence")
    return {"phase": phase, "draw_count": 10,
            "draw_witness_sha256": sha256(json.dumps(value["draws"], sort_keys=True,
                                                separators=(",", ":"),
                                                allow_nan=False).encode()).hexdigest(),
            "original_fixed_gene_scores_verified": 1000,
            "physical_blocks_queried": 126, "physical_values_compared": 7_565_140}


def gnu_cost(helper: ModuleType, ref: dict) -> dict:
    helper.exact_ref(ref, metadata=True)
    raw = helper.read_small(Path(ref["path"]))
    data = raw.decode("utf-8")
    match = re.search(r"^\s*Maximum resident set size \(kbytes\):\s*(\d+)\s*$", data, re.M)
    wall = re.search(r"^\s*Elapsed \(wall clock\) time \(h:mm:ss or m:ss\):\s*"
                     r"([0-9]+:[0-9]{2}(?::[0-9]{2})?(?:\.[0-9]+)?)\s*$", data, re.M)
    exit_code = re.search(r"^\s*Exit status:\s*(\d+)\s*$", data, re.M)
    need(match is not None and wall is not None and exit_code is not None
         and int(exit_code.group(1)) == 0, "Completed GNU child cost required")
    return {"reference": ref, "elapsed_wall_clock_text": wall.group(1).strip(),
            "peak_child_rss_kbytes": int(match.group(1)), "exit_status": 0,
            "scope": "GNU time child process, not aggregate process-tree memory"}


def capture(helper: ModuleType, attempt: Path, source_refs: dict) -> dict:
    need(attempt == (BASE / "common_source_10_attempt01").resolve(strict=True),
         "Only the reviewed fresh 10-draw attempt may be captured")
    marker_path = attempt / "summary.json"
    need(marker_path.is_file(), "Final 10-draw marker absent; incomplete attempt refused")
    final_ref = metadata_path(helper, marker_path)
    final = helper.load(marker_path)
    need(final.get("schema") == "b3_common_source_10_probe_driver_v1"
         and final.get("status") == "completed_actual_10_draw_probe_and_independent_replay"
         and isinstance(final.get("jobs"), list) and len(final["jobs"]) == 4,
         "Completed four-stage 10-draw final marker required")
    flags(final, "final")
    need(final.get("driver_source") == source_refs["driver"]
         and final.get("source_study") == source_refs["seven_stage_final"]
         and final.get("source_100_negative_gate") == source_refs["negative_100_gate"],
         "Final marker source binding differs")
    finite(final.get("elapsed_before_final_seal_seconds"), "final preseal", 4500)
    source_study = exact_json(helper, source_refs["seven_stage_final"])
    need(source_study.get("status") == "completed_one_draw_representative_study_and_cost_gate"
         and source_study.get("cost_gate") == source_refs["negative_100_gate"],
         "Seven-stage source result incomplete")
    source_gate = exact_json(helper, source_refs["negative_100_gate"])
    need(source_gate.get("bounded_100_draw_probe_permitted") is False
         and source_gate.get("full_2000_draw_stage_permitted") is False,
         "Original 100-draw negative gate changed")
    failed = final.get("failed_50_diagnostic")
    need(isinstance(failed, dict) and failed, "Failed-50 diagnostics absent")
    need(failed.get("stage_failed_during_final_seal") is True
         and failed.get("replay_or_qualification_launched") is False
         and failed.get("public_50_return_seconds") == 698.473401826006
         and failed.get("invalid_stage_before_final_seal_seconds") == 798.8693383089994
         and failed.get("complete_supervised_invocation_seconds") == 901.5519847889955,
         "Failed-50 diagnostic scope differs")
    failed_refs = {"source": {}, "metadata": {}}
    for group, expected in FAILED_50_SHA.items():
        values = failed.get(group)
        need(isinstance(values, dict) and set(values) == set(expected),
             f"Failed-50 {group} references differ")
        for name, value in values.items():
            admitted = helper.sealed_ref(value)
            need(admitted["collector_rehashed"], "Failed-50 diagnostic must be bounded metadata")
            need(value["sha256"] == expected[name],
                 f"Failed-50 {group}/{name} SHA differs")
            relative = ({"driver": "continue_common_source_50.py",
                         "instructions": "COMMON_SOURCE_50_PROBE.md"} if group == "source" else {
                             "root_failure": "failure.json",
                             "stage_failure": "stages/01-execute-50/failure.json",
                             "invalid_stage_summary": "stages/01-execute-50/invalid-summary.json",
                             "public_summary": "stages/01-execute-50/public/summary.json",
                             "supervisor_state": "supervisors/01-execute-50/state.json",
                             "controller_receipt": "controllers/01-execute-50-receipt.json",
                             "gnu_child_cost": "supervisors/01-execute-50/gnu-time.txt",
                         })[name]
            expected_path = ((DRAFT if group == "source" else
                              BASE / "common_source_50_attempt01") / relative).resolve(strict=True)
            need(value["path"] == str(expected_path),
                 f"Failed-50 {group}/{name} path differs")
            failed_refs[group][name] = value
    need(not (BASE / "common_source_50_attempt01/summary.json").exists(),
         "Failed-50 attempt unexpectedly gained a final marker")
    need(not (BASE / "common_source_50_attempt01/stages/01-execute-50/summary.json").exists()
         and not (BASE / "common_source_50_attempt01/stages/02-replay-50").exists()
         and not (BASE / "common_source_50_attempt01/stages/03-qualify").exists(),
         "Failed-50 attempt unexpectedly gained completed stages")
    gate_ref = final.get("admission_10_gate")
    admission = exact_json(helper, gate_ref)
    validate_admission(admission, source_refs["negative_100_gate"], failed)
    stage_refs, stages, jobs = {}, {}, []
    for (name, action), job in zip(STAGES, final["jobs"], strict=True):
        need(job.get("name") == name and job.get("action") == action
             and job.get("controller_return_code") == 0,
             f"{name} supervisor/controller incomplete")
        marker_ref = job.get("summary")
        need(marker_ref == metadata_path(helper, attempt / "stages" / name / "summary.json"),
             f"{name} stage summary differs")
        marker = exact_json(helper, marker_ref)
        need(marker.get("schema") == "b3_common_source_10_probe_stage_v1"
             and marker.get("status") == "complete" and marker.get("action") == action
             and marker.get("driver_source") == source_refs["driver"],
             f"{name} stage did not complete")
        flags(marker, name)
        finite(marker.get("elapsed_before_final_seal_seconds"), f"{name} preseal", 900)
        for item in [*marker.get("inputs", []), *marker.get("generated_files", [])]:
            helper.sealed_ref(item)
        state = exact_json(helper, job.get("supervisor_state"))
        need(state.get("status") == "completed" and state.get("return_code") == 0,
             f"{name} supervisor state failed")
        need(job.get("supervisor_state") == metadata_path(helper, attempt / "supervisors" / name / "state.json"),
             f"{name} supervisor path differs")
        gnu = gnu_cost(helper, job.get("gnu_complete_child_cost"))
        need(job["gnu_complete_child_cost"] == metadata_path(helper, attempt / "supervisors" / name / "gnu-time.txt"),
             f"{name} GNU path differs")
        supervised = finite(job.get("complete_supervised_invocation_monotonic_seconds"),
                            f"{name} complete supervised invocation", 955)
        stage_refs[name], stages[name] = marker_ref, marker
        jobs.append({"name": name, "action": action, "stage": marker_ref,
                     "cooperative_preseal_seconds": marker["elapsed_before_final_seal_seconds"],
                     "cooperative_stage_cap_seconds": 900,
                     "supervisor_state": job["supervisor_state"],
                     "supervised_invocation_seconds": supervised,
                     "supervisor_wall_cap_seconds": 950,
                     "gnu_child_cost": gnu,
                     "peak_process_rss_bytes": marker.get("peak_process_rss_bytes"),
                     "rss_scope": job.get("rss_scope")})
    binding_ref = stages["00-admit"].get("outputs", {}).get("binding")
    need(binding_ref == metadata_path(helper, attempt / "stages/00-admit/binding.json"),
         "Frozen 10-draw binding differs")
    binding = exact_json(helper, binding_ref)
    need(binding.get("schema") == "b3_common_source_10_probe_binding_v1"
         and binding.get("draw_range") == [0, 10]
         and binding.get("source_study_final") == source_refs["seven_stage_final"]
         and binding.get("source_100_negative_gate") == source_refs["negative_100_gate"]
         and binding.get("failed_50_diagnostic") == failed
         and binding.get("admission_10_gate") == gate_ref
         and binding.get("driver_source") == source_refs["driver"]
         and binding.get("instructions") == source_refs["instructions"]
         and binding.get("cooperative_stage_seconds") == 900
         and binding.get("supervised_stage_seconds") == 950
         and binding.get("rss_cap_bytes") == 4 * 1024**3
         and binding.get("numeric_cap_bytes") == 200 * 1024**2
         and len(binding.get("application_consumer_file_sha256", {})) == 82,
         "10-draw binding/source/caps differ")
    freeze_ref = binding.get("source_freeze")
    freeze = exact_json(helper, freeze_ref)
    need(freeze_ref == metadata_path(helper, BASE / "common_source_representative_attempt01/stages/00-freeze/binding.json")
         and len(freeze.get("original_native_consumer_file_sha256", {})) == 67
         and len(freeze.get("legacy_application_consumer_file_sha256", {})) == 74
         and len(freeze.get("batch_consumer_file_sha256", {})) == 69
         and len(freeze.get("application_consumer_file_sha256", {})) == 82
         and binding.get("source_keys") == freeze.get("source_keys")
         and binding.get("application_consumer_file_sha256") ==
             freeze.get("application_consumer_file_sha256"),
         "Seven-stage frozen source closure/keys differ")
    for name in PUBLIC_SHA:
        need(binding["application_consumer_file_sha256"].get(str(ROOT / name)) == PUBLIC_SHA[name],
             f"Frozen public source SHA differs: {name}")
    for name in ("01-execute-10", "02-replay-10", "03-qualify"):
        need(stages[name].get("binding") == binding_ref, f"{name} uses another binding")
    for item in binding.get("bound_files", []):
        helper.sealed_ref(item)
    public = {}
    for name, phase in (("01-execute-10", "production"), ("02-replay-10", "replay")):
        marker = stages[name]
        need(marker.get("details", {}).get("draw_range") == [0, 10]
             and marker["details"].get("measured_actual_10_draws") is True,
             f"{phase} measured stage scope differs")
        pub_ref = marker.get("outputs", {}).get("public_summary")
        need(pub_ref == metadata_path(helper, attempt / "stages" / name / "public/summary.json"),
             f"{phase} public summary differs")
        actual = exact_json(helper, pub_ref)
        need(actual == marker["details"].get("public_result"),
             f"{phase} public return differs from sealed summary")
        proof = validate_public(actual, phase)
        proof["summary"] = pub_ref
        proof["complete_public_return_monotonic_seconds"] = finite(
            marker["details"].get("complete_public_return_monotonic_seconds"),
            f"{phase} public return", 900)
        public[phase] = proof
    need(public["production"]["draw_witness_sha256"] ==
         public["replay"]["draw_witness_sha256"]
         and actual.get("prefix_query_replay_verified") is True,
         "Ten independent replay witnesses differ")
    gate_ref = final.get("cost_gate")
    need(gate_ref == stages["03-qualify"].get("outputs", {}).get("cost_gate")
         and gate_ref == metadata_path(helper, attempt / "stages/03-qualify/cost-gate.json"),
         "Actual 10-draw cost gate differs")
    cost = exact_json(helper, gate_ref)
    need(cost.get("schema") == "b3_common_source_10_probe_cost_gate_v1"
         and cost.get("status") == "actual_10_draw_production_and_replay_complete"
         and cost.get("source_100_negative_gate") == source_refs["negative_100_gate"]
         and cost.get("admission_10_gate") == final["admission_10_gate"]
         and cost.get("production_invocation_count_for_2000") == 200
         and cost.get("replay_invocation_count_for_2000") == 200
         and cost.get("other_invocations_unmeasured") == 398
         and cost.get("full_2000_draw_stage_permitted") is False
         and cost.get("full_2000_draws_completed") is False
         and cost.get("whole_method_fit_established") is False
         and cost.get("project_likelihood_effects_attested") is False
         and cost.get("scientific_readiness") == "unavailable"
         and cost.get("interval", object()) is None,
         "Cost arithmetic promoted beyond actual bounded evidence")
    costs = cost.get("costs")
    need(isinstance(costs, dict) and set(costs) == {"production", "replay"},
         "Both actual bounded costs required")
    for phase in costs:
        need(costs[phase].get("receipt") == public[phase]["summary"]
             and math.isclose(costs[phase].get("completed_10_draw_public_return_seconds"),
                              public[phase]["complete_public_return_monotonic_seconds"],
                              rel_tol=0, abs_tol=1e-8)
             and costs[phase].get("recorded_component_timings_seconds") ==
             exact_json(helper, public[phase]["summary"]).get("timings_seconds"),
             f"Actual {phase} cost/component timing differs")
    expected = 200 * sum(public[p]["complete_public_return_monotonic_seconds"]
                         for p in ("production", "replay"))
    need(math.isclose(cost.get("projected_400_shard_calls_seconds"), expected,
                      rel_tol=0, abs_tol=1e-8), "400-call descriptive arithmetic differs")
    private = final.get("private_generated_files")
    need(isinstance(private, list) and private, "Private generated file seal absent")
    private_refs = [helper.sealed_ref(item) for item in private]
    return {"schema": SCHEMA, "status": "completed_bounded_10_draw_engineering_evidence_only",
            "tracked_head": HEAD, "source_refs": source_refs,
            "final_marker": final_ref, "seven_stage_source": source_refs["seven_stage_final"],
            "original_negative_100_gate": source_refs["negative_100_gate"],
            "failed_50_diagnostics_only": failed_refs,
            "admission_10_gate": {"reference": final["admission_10_gate"], "forecasts": admission["forecasts"],
                                  "engineering_reserve_seconds": 300},
            "binding": binding_ref, "four_stage_jobs": jobs,
            "public_10": public, "cost_gate": {"reference": gate_ref,
                "costs": costs, "projected_400_shard_calls_seconds": expected,
                "production_invocations_for_2000": 200, "replay_invocations_for_2000": 200,
                "other_invocations_unmeasured": 398},
            "private_generated_file_seals": private_refs,
            "private_payload_verification_limit": "Metadata allowlist <=32 MiB rehashed; H5, numeric, unknown and oversized payloads retain producer SHA shape plus current size only",
            "clock_scopes": "Public API return, cooperative stage preseal, complete supervised invocation, and GNU child wall/peak are distinct",
            "synthetic_fixture_only": True, "model_forwards_performed": False,
            "checkpoint_tensors_loaded": False, "native_arithmetic_replay_verified": False,
            "native_likelihood_effects_attested": False, "scientific_readiness": "unavailable",
            "interval": None, "full_2000_draws_completed": False,
            "whole_method_fit_established": False,
            "ticket_05_science_cost_full_cohort_acceptance": "open",
            "public_75_full_suite_acceptance": "separate_evidence_not_inferred_here"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-capture-sha256", required=True)
    args = parser.parse_args()
    own_ref, _ = admitted_source(OWN_CALLER, checked_sha(args.expected_capture_sha256))
    helper, helper_ref = load_reviewed_helper()
    output = args.output.absolute()
    created_identity = None
    try:
        need(not os.path.lexists(output), "Never replace an existing evidence output")
        need(helper.small_ref(OWN_CALLER) == own_ref
             and helper.small_ref(HELPER) == helper_ref,
             "Own and reviewed-helper canonical source pins differ from retained bytes")
        need(helper.git("rev-parse", "HEAD").decode().strip() == HEAD,
             "Tracked HEAD differs from reviewed source")
        index_before = helper.index_entries()
        need(index_before == helper.tree_entries(HEAD), "Index differs from reviewed HEAD")
        source_refs = {"capture": own_ref, "reviewed_metadata_helper": helper_ref}
        for key, path, expected in (
            ("driver", DRAFT / "continue_common_source_10.py", DRIVER_SHA),
            ("instructions", DRAFT / "COMMON_SOURCE_10_PROBE.md", INSTRUCTIONS_SHA),
            ("two_axis_static_review", DRAFT / "common_source_10_review_record.md", REVIEW_SHA),
        ):
            source_refs[key] = metadata_path(helper, path, expected)
        review_text = helper.read_small(DRAFT / "common_source_10_review_record.md").decode()
        need("Standards reviewer" in review_text and "Spec reviewer" in review_text
             and "zero hard and zero optional findings" in review_text,
             "Both independent static axes must be recorded")
        for name, expected in PUBLIC_SHA.items():
            source_refs[name] = metadata_path(helper, ROOT / name, expected)
        study = BASE / "common_source_representative_attempt01"
        source_refs["seven_stage_final"] = metadata_path(
            helper, study / "summary.json",
            "85598c6ebb370b3d3ad1e1f056dad69c15cb576a730637d1dd9e38c3f732c6fd")
        source_refs["negative_100_gate"] = metadata_path(
            helper, study / "stages/06-qualify/cost-gate.json",
            "c4206cb33365380a01f0a9a0987460cb88b2ca8a953a570298fa6e2cdd931671")
        report = capture(helper, args.attempt.resolve(strict=True), source_refs)
        report["capture_source"] = own_ref
        report["reviewed_metadata_helper"] = helper_ref
        report["git_index_inventory_count"] = len(index_before)
        helper.recheck_pins()
        need(helper.git("rev-parse", "HEAD").decode().strip() == HEAD
             and helper.index_entries() == index_before,
             "HEAD or full index changed before evidence seal")
        need(helper.small_ref(OWN_CALLER) == own_ref
             and helper.small_ref(HELPER) == helper_ref,
             "Own or reviewed-helper source changed before evidence seal")
        serialized = json.dumps(report, sort_keys=True, separators=(",", ":"),
                                allow_nan=False).encode() + b"\n"
        need(len(serialized) <= 32 * 1024**2, "Evidence metadata exceeds 32 MiB")
        with output.open("xb") as stream:
            created = os.fstat(stream.fileno())
            need(stat.S_ISREG(created.st_mode), "Owned evidence output is not regular")
            created_identity = (created.st_dev, created.st_ino)
            stream.write(serialized)
            stream.flush()
            os.fsync(stream.fileno())
        helper.recheck_pins()
        need(helper.git("rev-parse", "HEAD").decode().strip() == HEAD
             and helper.index_entries() == index_before,
             "HEAD or full index changed after evidence fsync")
        need(helper.small_ref(OWN_CALLER) == own_ref
             and helper.small_ref(HELPER) == helper_ref,
             "Own or reviewed-helper source changed after evidence fsync")
        completed = os.lstat(output)
        need(stat.S_ISREG(completed.st_mode)
             and (completed.st_dev, completed.st_ino) == created_identity
             and completed.st_size == len(serialized),
             "Owned evidence output changed during final seal")
    except BaseException:
        if created_identity is not None:
            try:
                candidate = os.lstat(output)
                if (stat.S_ISREG(candidate.st_mode)
                    and (candidate.st_dev, candidate.st_ino) == created_identity):
                    output.unlink()
            except FileNotFoundError:
                pass
        raise
    finally:
        if sys.modules.get(helper.__name__) is helper:
            del sys.modules[helper.__name__]


if __name__ == "__main__":
    main()
