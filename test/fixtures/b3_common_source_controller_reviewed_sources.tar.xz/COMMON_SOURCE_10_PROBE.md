# New bounded 10-draw common-source continuation

Status: ignored, **unexecuted** draft for independent Standards and Spec static
review. The completed seven-stage study and failed 50-draw attempt remain
immutable separate evidence. This new driver uses `b3_common_source_10_*_v1`
stage, binding, admission, cost and final schemas. It follows the bounded
feasibility choice in [ADR 0005](../../../../docs/adr/0005-b3-feasibility-before-full-cohort-expansion.md):
scientific protocol and full-cohort production are unchanged.

The original one-draw [cost gate](../common_source_representative_attempt01/stages/06-qualify/cost-gate.json)
sets `bounded_100_draw_probe_permitted=false`; 100-draw forecasts with
headroom were 969.0468832214356 and 978.9312059593613 seconds, above the
900-second cooperative stage cap. The distinct
[failed 50-draw attempt](../common_source_50_attempt01/failure.json) has no
accepted final or execute-stage summary. Its production public API returned
50 draws after 698.473401826006 seconds, but the `invalid-summary.json`
recorded 798.8693383089994 seconds before the stage's final seal. A
`TimeoutError: Study stage wall cap exceeded` occurred in final reference
checks. The complete supervised invocation was 901.5519847889955 seconds;
its supervisor stopped with return code 1. GNU child wall was `13:52.09`,
peak RSS 763148 kbytes, exit status 1. There was no 50-draw replay or qualify
stage. These public, draft-stage, GNU and supervised clocks have different
scopes. The public-only return and invalid stage draft **must not** be
promoted to a completed 50-draw result.

## New 10-draw admission

The parent authenticates the completed seven-stage final marker and negative
100-draw gate, the exact reviewed failed-50 driver/instructions, and these
failed-50 diagnostic metadata files, each at its original path and SHA-256:
root `failure.json`, stage `01-execute-50/failure.json`, its
`invalid-summary.json`, its public `summary.json`, the stage supervisor state,
controller receipt and GNU time text. All are at most 32 MiB. The failed
50-draw files are **diagnostics only**; no failed artifact, draw, stage marker
or cost is reused as a new 10-draw result.

Before any child launch, the parent derives a separate source-bound 10-draw
admission for **both** production and replay from the completed one-draw
public-return receipt:

```text
projection = measured complete one-draw return
           + 9 × recorded per-draw query-kernel/serialization time
           + 300 seconds proposed engineering reserve
headroom = max(60 seconds, 25% × projection)
require projection + headroom <= 900 seconds for each phase
```

The explicit 300 seconds covers possible outer source admission, controls,
validation and final seal work. It is a **proposed safety reserve for another
bounded measurement**, not an upper-bound guarantee inferred from the failed
50-draw trace. The original negative 100 gate and failed 50 result remain
negative/failed. A negative new 10 projection or changed source byte produces
an honest new-attempt failure marker with zero children launched.

## Invocation after independent source review

Use a fresh output directory. Pin the final new driver and this instruction
file by independently reviewed SHA-256, plus the frozen seven-stage driver,
public v3 application and authenticated helper. The failed-50 path is fixed
to the original attempt; its sources and seven diagnostic files are checked
against exact SHA-256 values embedded in the new reviewed driver.

```bash
.venv/bin/python runs/b3_feasibility/20261004/common_source_draft/continue_common_source_10.py run \
  --output runs/b3_feasibility/20261004/common_source_10_attempt01 \
  --study runs/b3_feasibility/20261004/common_source_representative_attempt01 \
  --failed-50 runs/b3_feasibility/20261004/common_source_50_attempt01 \
  --expected-driver-sha256 REVIEWED_10_DRIVER_SHA256 \
  --expected-instructions-sha256 REVIEWED_THIS_FILE_SHA256 \
  --expected-study-sha256 REVIEWED_SEVEN_STAGE_DRIVER_SHA256 \
  --expected-app-sha256 REVIEWED_PUBLIC_V3_APPLICATION_SHA256 \
  --expected-auth-helper-sha256 REVIEWED_SHARED_AUTHENTICATION_HELPER_SHA256
```

The parent authenticates its new driver/doc, historical freeze, original
67/74 and current 69/82 consumer maps, frozen source keys, v3 plan, two
completed builds, public application and supervisor **before** any launch.
It writes a distinct `admission-10-gate.json` and `prelaunch.json`; the child
`00-admit` independently recomputes the same projection. The parent rechecks
all bound source, historical, diagnostic and new-admission references
immediately before every owned supervisor launch.

## Four-stage bounded sequence

| New stage | Required work |
| --- | --- |
| `00-admit` | Bind the completed seven-stage negative 100 gate, exact failed-50 diagnostics, and separate eligible 10-draw admission. |
| `01-execute-10` | Fresh public v3 production for frozen draws `0:10`; require exactly 10 draw witnesses, all 1,000 original fixed-gene scores, 126 physical blocks and 7,565,140 compared scalars. |
| `02-replay-10` | Fresh independent public replay of exactly `0:10` against this attempt's new production catalog; require the same controls and exact draw-witness equality. |
| `03-qualify` | Record actual complete public-return and component clocks; describe 200 production plus 200 replay invocations for 2,000-draw arithmetic only. |

Each stage has one 900-second cooperative budget **starting before the
reviewed helper loads and continuing through all postchecks and final seal**.
Its supervisor has a 950-second wall cap. The four-stage parent's 4,500-second
cap also starts before helper admission. The helper source must be a regular
file at most 4 MiB, read into and executed from the exact SHA-verified bounded
compile buffer. One CPU thread, disabled CUDA, 4 GiB process RSS cap, 4 GiB
available host RAM floor, 20 GiB free disk floor and 200 MiB public numeric
working cap remain in force. The parent cleans only its owned live supervisor
process group after identity checks; failed stages cannot trigger later ones.
The final marker is written last after verifying original, frozen, failed-50
diagnostic, new private/generated and child input references.

Even a completed 10-draw production and replay would leave **199 further
production plus 199 further replay invocations** and a source-bound finalizer
unmeasured. The resulting 400-call arithmetic is descriptive; no 2,000-draw
job starts automatically. Native arithmetic and project likelihood effects
remain unattested, scientific readiness stays `unavailable`, interval stays
`null`. The genuine project's original 5,111/15,705 finite pairs (32.54%)
and 0/2,000 jointly supported draws still veto a reportable comparison.
Ticket 05 stays open and ticket 11 remains excluded.
